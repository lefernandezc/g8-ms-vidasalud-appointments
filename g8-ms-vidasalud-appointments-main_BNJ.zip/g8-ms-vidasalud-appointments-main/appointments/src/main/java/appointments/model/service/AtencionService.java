package appointments.model.service;

import appointments.model.Atencion;
import appointments.model.EstadoAtencion;
import appointments.model.repository.AtencionRepository;
import appointments.rabbitmq.Sender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;

@Service
@RequiredArgsConstructor
public class AtencionService {
    
    private final AtencionRepository repository;
    private final Sender rabbitSender;

    @Transactional
    public Atencion crear(Atencion atencion){
        LocalDateTime inicio = atencion.getFechaHora().minusMinutes(15);
        LocalDateTime fin = atencion.getFechaHora().plusMinutes(15);

        if (repository.existsByProfesionalIdAndFechaHoraBetweenAndEstadoNot(
                atencion.getProfesionalId(), inicio, fin, EstadoAtencion.CANCELADA)) {
            throw new IllegalStateException("Sin cupo: El profesional ya tiene una atención en ese horario.");
        }

        atencion.setEstado(EstadoAtencion.SOLICITADA);
        Atencion guardada = repository.save(atencion);
        
        // Notificación de evento
        rabbitSender.enviarNotificacionEmail(
            guardada.getId(), 
            guardada.getEstado().name(), 
            "paciente" + guardada.getPacienteId() + "@correo.com"
        );
        
        return guardada;
    }

    @Transactional
    public Atencion cambiarEstado(Long id, EstadoAtencion nuevoEstado){
        Atencion atencion = repository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Atención no encontrada con ID: " + id));
        
        EstadoAtencion actual = atencion.getEstado();

        boolean transicionValida = switch (actual) {
            case SOLICITADA -> nuevoEstado == EstadoAtencion.CONFIRMADA || nuevoEstado == EstadoAtencion.CANCELADA;
            case CONFIRMADA -> nuevoEstado == EstadoAtencion.EN_ESPERA || nuevoEstado == EstadoAtencion.CANCELADA;
            case EN_ESPERA -> nuevoEstado == EstadoAtencion.EN_ATENCION || nuevoEstado == EstadoAtencion.CANCELADA;
            case EN_ATENCION -> nuevoEstado == EstadoAtencion.CERRADA;
            case CERRADA, CANCELADA -> false;
        };

        if (!transicionValida) {
            throw new IllegalStateException("Regla de negocio violada: No se puede pasar de " + actual + " a " + nuevoEstado);
        }

        atencion.setEstado(nuevoEstado);
        Atencion actualizada = repository.save(atencion);
        
        rabbitSender.enviarNotificacionEmail(
            actualizada.getId(), 
            actualizada.getEstado().name(), 
            "paciente" + actualizada.getPacienteId() + "@correo.com"
        );
        
        return actualizada;
    }

    @Transactional(readOnly = true)
    public List<Atencion> listar(){
        return repository.findAll();
    }
}