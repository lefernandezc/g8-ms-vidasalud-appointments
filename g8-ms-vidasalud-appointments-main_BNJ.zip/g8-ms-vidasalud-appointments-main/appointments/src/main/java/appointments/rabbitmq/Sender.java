package appointments.rabbitmq;


import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class Sender {

    private final RabbitTemplate rabbitTemplate;

    @Value("${messaging.exchange.direct}")
    private String exchange;

    @Value("${messaging.routing.email}")
    private String routingEmail;

    public Sender(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void enviarNotificacionEmail(Long idAtencion, String estado, String correoPaciente) {
        // Creamos un mapa (o DTO) que Spring convertirá automáticamente a JSON
        Map<String, Object> mensaje = new HashMap<>();
        mensaje.put("idAtencion", idAtencion);
        mensaje.put("estado", estado);
        mensaje.put("email", correoPaciente);
        mensaje.put("tipo", "NOTIFICACION_ESTADO");

        rabbitTemplate.convertAndSend(exchange, routingEmail, mensaje);
        System.out.println("Mensaje enviado a RabbitMQ para notificar estado: " + estado);
    }
}