package appointments.rabbitmq;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    @Value("${messaging.exchange.direct}")
    private String exchangeName;

    @Value("${messaging.routing.email}")
    private String routingKeyEmail;

    @Bean
    public DirectExchange appointmentsExchange() {
        return new DirectExchange(exchangeName);
    }

    @Bean
    public Queue emailQueue() {
        return QueueBuilder.durable("queue.notifications.email").build();
    }

    @Bean
    public Binding emailBinding(Queue emailQueue, DirectExchange appointmentsExchange) {
        return BindingBuilder.bind(emailQueue).to(appointmentsExchange).with(routingKeyEmail);
    }

    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory, MessageConverter jsonMessageConverter) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(jsonMessageConverter);
        return template;
    }
}